<?php
use Modules\Weather\Http\Controllers\Frontend\IndexController;
//Route::get('/', 'IndexController@index');
//Route::get('/weather', [IndexController::class, 'index']);

Route::group(['middleware' => 'auth'], function() {
    Route::get('/', 'IndexController@index');
    Route::post('/metar', [IndexController::class, 'getMetar']);
});
/*
 * To register a route that needs to be authentication, wrap it in a
 * Route::group() with the auth middleware
 */
// Route::group(['middleware' => 'auth'], function() {
//     Route::get('/', 'IndexController@index');
// })
