<?php
/**
 * Provide any configuration items here
 */

return [
    'name' => 'Weather'
];
